/**
 * @brief       i2c_ESP.h
 * @details     ESP-IDF I2C function libraries.
 *              Header file.
 *
 *
 * @return      NA
 *
 * @author      Karl Maxwell
 * @date        12/May/2022
 * @version     22/May/2022    The ORIGIN
 * @pre         NaN
 * @warning     This file is ONLY for ESP-IDF device.
 * @pre         This code belongs to AqueronteBlog ( http://unbarquero.blogspot.com ).
 */

#ifndef I2C_ESP_H_
#define I2C_ESP_H_

#include <stdbool.h>

#include <driver/i2c.h>

/**
  * @brief   INTERNAL CONSTANTS
  */
typedef enum
{
	I2C_STOP_BIT  	 =   0x00,
	I2C_NO_STOP_BIT  =   0x01,
	I2C_TIMEOUT		 =	 1000,  // milliseconds
} i2c_internal_constants_t;


typedef enum
{
    I2C_SUCCESS  =   0x00,
    I2C_FAILURE  =   0x01
} i2c_status_t;


typedef enum
{
    I2C_WRITE  =   0x00,
    I2C_READ   =   0x01
} i2c_write_read_t;


/**
  * @brief   I2C PARAMETERS
  */
typedef struct{
    // Port
	i2c_port_t port;

    // Pin number
	gpio_num_t SDA;
	gpio_num_t SCL;

	gpio_pullup_t SDA_Pullup;
	gpio_pullup_t SCL_Pullup;

    // I2C frequency
    uint32_t I2C_Freq;

    // I2C Address
    uint8_t ADDR;

    // Check ack from slave (true: yes, false: no)
    bool ack_Check_Enable;
} I2C_parameters_t;




/**
  * @brief   FUNCTION PROTOTYPES
  */
i2c_status_t    i2c_write   ( I2C_parameters_t myI2Cparameters, uint8_t* i2c_buff, uint32_t length, uint32_t i2c_generate_stop );
i2c_status_t    i2c_read    ( I2C_parameters_t myI2Cparameters, uint8_t* i2c_buff, uint32_t length );
i2c_status_t    i2c_init    ( I2C_parameters_t myI2Cparameters );

#endif /* I2C_ESP_H_ */
