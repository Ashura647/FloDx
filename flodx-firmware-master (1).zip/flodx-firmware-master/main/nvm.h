/*
 * nvm.h
 *
 *  Created on: 2 Mar 2020
 *      Author: Karl.Maxwell
 */

#ifndef MAIN_NVM_H_
#define MAIN_NVM_H_

#include "nvs_flash.h"

#define STORAGE_NAMESPACE "storage"

esp_err_t nvm_init();
esp_err_t nvm_read_value(const char* key, void* out_value, const size_t size);
esp_err_t nvm_write_value(const char* key, const void* value, const size_t size);
esp_err_t nvm_erase_all();

#endif /* MAIN_NVM_H_ */
