/*
 * adc_ESP.h
 *
 *  Created on: 28 Jun 2022
 *      Author: Karl.Maxwell
 */

#ifndef ADC_ESP_H_
#define ADC_ESP_H_

#include <stdlib.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "driver/adc.h"
#include "esp_adc_cal.h"

typedef struct {
	adc_unit_t unit;
	adc_channel_t channel;
	adc_atten_t atten;
	adc_bits_width_t bit_width;
	uint32_t default_vref;
	uint32_t no_of_samples;
	esp_adc_cal_characteristics_t *adc_chars;
} adc_parameters_t;

typedef struct {
	uint32_t raw_reading;
	uint32_t voltage_mV;
} adc_reading_t;

void ADCInit(adc_parameters_t *adc_params);
void ADCRead(adc_parameters_t *adc_params, adc_reading_t *reading);

#endif /* ADC_ESP_H_ */
