/**
 * @brief       SHT4X.c
 * @details     Humidity and Temperature Sensor.
 *              Functions file.
 *
 *
 * @return      N/A
 *
 * @author      Karl Maxwell
 * @date        30/May/2022
 * @version     30/May/2022    The ORIGIN
 * @pre         N/A
 * @warning     N/A
 * @pre         This code belongs to Nimbus Centre ( http://www.nimbus.cit.ie ).
 */

 #include "SHT4X.h"


 /**
 * @brief       SHT4X_Init ( I2C_parameters_t )
 *
 * @details     It configures the I2C peripheral.
 *
 * @param[in]    myI2Cparameters:       I2C parameters.
 *
 * @param[out]   N/A.
 *
 *
 * @return       Status of SHT4X_Init.
 *
 *
 * @author      Karl Maxwell
 * @date        30/May/2022
 * @version     30/May/2022   The ORIGIN
 * @pre         N/A
 * @warning     N/A.
 */
SHT4X_status_t  SHT4X_Init ( I2C_parameters_t myI2Cparameters )
{
  i2c_status_t aux;

  aux  =   i2c_init ( myI2Cparameters );



  if ( aux == I2C_SUCCESS )
  {
      return   SHT4X_SUCCESS;
  }
  else
  {
      return   SHT4X_FAILURE;
  }
}

/**
 * @brief       SHT4X_StartMeasureTAndRH ( I2C_parameters_t , SHT4X_precision_t )
 * @details     It reads temperature and relative humidity.
 *
 * @param[in]    myI2Cparameters: I2C parameters.
 *
 * @param[in]    precision:       Precision of temperature and relative humidity readings
 *
 * @return      Status of SHT4X_StartMeasureTAndRH.
 *
 * @author      Karl Maxwell
 * @date        30/May/2022
 * @version     30/May/2022    The ORIGIN
 * @pre         N/A
 * @warning     @warning     The user MUST respect the total conversion time.
 *              low  precision: 1.3ms (1.7 max)
 *              med. precision: 3.7ms (4.5 max)
 *              high precision: 6.9ms (8.2 max)
 */
SHT4X_status_t  SHT4X_StartMeasureTAndRH     ( I2C_parameters_t myI2Cparameters, SHT4X_precision_t precision )
{
	uint8_t       cmd;
	i2c_status_t  aux;

	switch (precision) {
	case SHT4X_PRECISION_HIGH:
		cmd = SHT4X_MEASURE_HIGH_PRECISION;
		break;
	case SHT4X_PRECISION_MEDIUM:
		cmd = SHT4X_MEASURE_MEDIUM_PRECISION;
		break;
	case SHT4X_PRECISION_LOW:
		cmd = SHT4X_MEASURE_LOW_PRECISION;
		break;
	default:
		break;
	}

	/* Write to the register  */
	aux  = i2c_write ( myI2Cparameters, &cmd, 1, I2C_STOP_BIT );

	if ( aux == I2C_SUCCESS )
	{
	  return   SHT4X_SUCCESS;
	}
	else
	{
	  return   SHT4X_FAILURE;
	}
}

/**
 * @brief       SHT4X_GetDataTAndRH ( I2C_parameters_t , SHT4X_data_t* )
 * @details     It reads temperature and relative humidity.
 *
 * @param[in]    myI2Cparameters: I2C parameters.
 *
 * @param[out]   data:         All the raw data, calculated data and their CRC values.
 *
 *
 * @return      Status of SHT4X_GetDataTAndRH.
 *
 * @author      Karl Maxwell
 * @date        30/May/2022
 * @version     30/May/2022    The ORIGIN
 * @pre         N/A
 * @warning     The measuring time depends on the chosen precision. The user MUST take this into account.
 * @warning     SHT4X_StartMeasureTAndRH MUST be call before.
 */
SHT4X_status_t  SHT4X_GetDataTAndRH     ( I2C_parameters_t myI2Cparameters, SHT4X_data_t* data  )
{
	uint8_t       cmd[6] = { 0U };
	i2c_status_t  aux;

	/* Read the register  */
	aux = i2c_read  ( myI2Cparameters, &cmd[0], sizeof( cmd )/sizeof( cmd[0] ) );

	/* Parse the data  */
	data->rawTemperature        =   cmd[0];
	data->rawTemperature      <<=   8U;
	data->rawTemperature       |=   cmd[1];

	data->temperatureCRC        =   cmd[2];

	data->rawRelativeHumidity   =   cmd[3];
	data->rawRelativeHumidity <<=   8U;
	data->rawRelativeHumidity  |=   cmd[4];

	data->relativeHumidityCRC   =   cmd[5];

	data->temperature      = -45 + (175 * (float)data->rawTemperature) / 65535;
	data->relativeHumidity = -6  + (125 * (float)data->rawRelativeHumidity) / 65535;

	if ( aux == I2C_SUCCESS )
	{
	  return   SHT4X_SUCCESS;
	}
	else
	{
	  return   SHT4X_FAILURE;
	}
}



/**
 * @brief       SHT4X_SetSoftReset ( I2C_parameters_t )
 * @details     It performs a software reset.
 *
 * @param[in]    myI2Cparameters: I2C parameters.
 *
 * @param[out]   N/A
 *
 *
 * @return      Status of SHT4X_SetSoftReset.
 *
 * @author      Karl Maxwell
 * @date        30/May/2022
 * @version     30/May/2022    The ORIGIN
 * @pre         N/A
 * @warning     N/A.
 */
SHT4X_status_t  SHT4X_SetSoftReset ( I2C_parameters_t myI2Cparameters )
{
	uint8_t       cmd = SHT4X_SOFT_RESET;
	i2c_status_t  aux;

	aux      =  i2c_write ( myI2Cparameters, &cmd, 1, I2C_STOP_BIT );


	if ( aux == I2C_SUCCESS )
	{
	  return   SHT4X_SUCCESS;
	}
	else
	{
	  return   SHT4X_FAILURE;
	}
}



///**
// * @brief       SHT4X_SetGeneralCallReset ( I2C_parameters_t )
// * @details     It perfoms a reset through a general call address.
// *
// * @param[in]    myI2Cparameters: I2C parameters.
// *
// * @param[out]   N/A
// *
// *
// * @return      Status of SHT4X_SetGeneralCallReset.
// *
// * @author      Karl Maxwell
// * @date        30/May/2022
// * @version     30/May/2022    The ORIGIN
// * @pre         N/A
// * @warning     N/A.
// */
//SHT4X_status_t  SHT4X_SetGeneralCallReset ( I2C_parameters_t myI2Cparameters )
//{
//  uint8_t       cmd;
//  uint8_t       aux_addr;
//  i2c_status_t  aux;
//
//  /* Save previous address   */
//  aux_addr =   myI2Cparameters.ADDR;
//
//  /* Write the register  */
//  myI2Cparameters.ADDR   =  SHT4X_GENERAL_CALL_RESET_ADDRESS_BYTE;
//  cmd                    =  SHT4X_GENERAL_CALL_RESET_SECOND_BYTE;
//  aux                    =  i2c_write ( myI2Cparameters, &cmd, 1U, I2C_STOP_BIT );
//
//  /* Restore previous address  */
//  myI2Cparameters.ADDR   =   aux_addr;
//
//
//  if ( aux == I2C_SUCCESS )
//  {
//      return   SHT4X_SUCCESS;
//  }
//  else
//  {
//      return   SHT4X_FAILURE;
//  }
//}
//
//
//
///**
// * @brief       SHT4X_SetHeater ( I2C_parameters_t )
// * @details     It sets the heater.
// *
// * @param[in]    myI2Cparameters: I2C parameters.
// * @param[in]    heater:          Enable/Disable.
// *
// * @param[out]   N/A
// *
// *
// * @return      Status of SHT4X_SetHeater.
// *
// * @author      Karl Maxwell
// * @date        30/May/2022
// * @version     30/May/2022    The ORIGIN
// * @pre         N/A
// * @warning     N/A.
// */
//SHT4X_status_t  SHT4X_SetHeater ( I2C_parameters_t myI2Cparameters, SHT4X_command_registers_heater_t heater )
//{
//  uint8_t       cmd[2] = { 0U };
//  i2c_status_t  aux;
//
//  /* Write the register  */
//  cmd[0]   =  (uint8_t)( heater >> 8U );
//  cmd[1]   =  (uint8_t)( heater & 0xFF );
//  aux      =  i2c_write ( myI2Cparameters, &cmd[0], sizeof( cmd )/sizeof( cmd[0] ), I2C_STOP_BIT );
//
//
//  if ( aux == I2C_SUCCESS )
//  {
//      return   SHT4X_SUCCESS;
//  }
//  else
//  {
//      return   SHT4X_FAILURE;
//  }
//}
//
//
//
///**
// * @brief       SHT4X_GetStatus ( I2C_parameters_t , SHT4X_status_data_t* )
// * @details     It gets the status register.
// *
// * @param[in]    myI2Cparameters: I2C parameters.
// *
// * @param[out]   status:          The wole status register and its CRC.
// *
// *
// * @return      Status of SHT4X_GetStatus.
// *
// * @author      Karl Maxwell
// * @date        30/May/2022
// * @version     30/May/2022    The ORIGIN
// * @pre         N/A
// * @warning     N/A.
// */
//SHT4X_status_t  SHT4X_GetStatus ( I2C_parameters_t myI2Cparameters, SHT4X_status_data_t* status )
//{
//  uint8_t       cmd[3] = { 0U };
//  i2c_status_t  aux    = SHT4X_SUCCESS;
//
//  /* Write the register  */
//  cmd[0]   =  (uint8_t)( SHT4X_STATUS_REGISTER >> 8U );
//  cmd[1]   =  (uint8_t)( SHT4X_STATUS_REGISTER & 0xFF );
//  aux     |=  i2c_write ( myI2Cparameters, &cmd[0], 2U, I2C_NO_STOP_BIT );
//
//  /* Read the register   */
//  aux     |=  i2c_read ( myI2Cparameters, &cmd[0], sizeof( cmd )/sizeof( cmd[0] ) );
//
//  /* Parse the data  */
//  status->status     =   cmd[0];
//  status->status   <<=   8U;
//  status->status    |=   cmd[1];
//
//  status->statusCRC  =   cmd[2];
//
//
//
//  if ( aux == I2C_SUCCESS )
//  {
//      return   SHT4X_SUCCESS;
//  }
//  else
//  {
//      return   SHT4X_FAILURE;
//  }
//}
//
//
//
///**
// * @brief       SHT4X_ClearStatus ( I2C_parameters_t )
// * @details     It clears the status register.
// *
// * @param[in]    myI2Cparameters: I2C parameters.
// *
// * @param[out]   N/A.
// *
// *
// * @return      Status of SHT4X_ClearStatus.
// *
// * @author      Karl Maxwell
// * @date        30/May/2022
// * @version     30/May/2022    The ORIGIN
// * @pre         N/A
// * @warning     N/A.
// */
//SHT4X_status_t  SHT4X_ClearStatus ( I2C_parameters_t myI2Cparameters )
//{
//  uint8_t       cmd[2] = { 0U };
//  i2c_status_t  aux;
//
//  /* Write the register  */
//  cmd[0]   =  (uint8_t)( SHT4X_CLEAR_STATUS_REGISTER >> 8U );
//  cmd[1]   =  (uint8_t)( SHT4X_CLEAR_STATUS_REGISTER & 0xFF );
//  aux      =  i2c_write ( myI2Cparameters, &cmd[0], sizeof( cmd )/sizeof( cmd[0] ), I2C_STOP_BIT );
//
//
//
//  if ( aux == I2C_SUCCESS )
//  {
//      return   SHT4X_SUCCESS;
//  }
//  else
//  {
//      return   SHT4X_FAILURE;
//  }
//}
//
//
//
///**
// * @brief       SHT4X_SetPeriodicAquisitionMode ( I2C_parameters_t , SHT4X_command_registers_periodic_data_mode_t )
// * @details     It sets the periodic data aquisition mode.
// *
// * @param[in]    myI2Cparameters: I2C parameters.
// * @param[in]    mo:              Periodic aquisition mode.
// *
// * @param[out]   N/A.
// *
// *
// * @return      Status of SHT4X_SetPeriodicAquisitionMode.
// *
// * @author      Karl Maxwell
// * @date        30/May/2022
// * @version     30/May/2022    The ORIGIN
// * @pre         N/A
// * @warning     N/A.
// */
//SHT4X_status_t  SHT4X_SetPeriodicAquisitionMode ( I2C_parameters_t myI2Cparameters, SHT4X_command_registers_periodic_data_mode_t mo )
//{
//  uint8_t       cmd[2] = { 0U };
//  i2c_status_t  aux;
//
//  /* Write the register  */
//  cmd[0]   =  (uint8_t)( mo >> 8U );
//  cmd[1]   =  (uint8_t)( mo & 0xFF );
//  aux      =  i2c_write ( myI2Cparameters, &cmd[0], sizeof( cmd )/sizeof( cmd[0] ), I2C_STOP_BIT );
//
//
//
//  if ( aux == I2C_SUCCESS )
//  {
//      return   SHT4X_SUCCESS;
//  }
//  else
//  {
//      return   SHT4X_FAILURE;
//  }
//}
//
//
//
///**
// * @brief       SHT4X_GetAllRawDataFetchData ( I2C_parameters_t , SHT4X_raw_data_t* )
// * @details     It gets the all raw data (in periodic aquisition mode).
// *
// * @param[in]    myI2Cparameters: I2C parameters.
// *
// * @param[out]   rawData:         Raw data and their CRC values.
// *
// *
// * @return      Status of SHT4X_GetAllRawDataFetchData.
// *
// * @author      Karl Maxwell
// * @date        30/May/2022
// * @version     30/May/2022    The ORIGIN
// * @pre         N/A
// * @warning     N/A.
// */
//SHT4X_status_t  SHT4X_GetAllRawDataFetchData ( I2C_parameters_t myI2Cparameters, SHT4X_raw_data_t* rawData )
//{
//  uint8_t       cmd[6] = { 0U };
//  i2c_status_t  aux;
//
//  /* Write the register  */
//  cmd[0]   =  (uint8_t)( SHT4X_FETCH_DATA >> 8U );
//  cmd[1]   =  (uint8_t)( SHT4X_FETCH_DATA & 0xFF );
//  aux      =  i2c_write ( myI2Cparameters, &cmd[0], sizeof( cmd )/sizeof( cmd[0] ), I2C_NO_STOP_BIT );
//
//  /* Read the register   */
//  aux      =  i2c_read ( myI2Cparameters, &cmd[0], sizeof( cmd )/sizeof( cmd[0] ) );
//
//  /* Parse the data  */
//  rawData->rawTemperature        =   cmd[0];
//  rawData->rawTemperature      <<=   8U;
//  rawData->rawTemperature       |=   cmd[1];
//
//  rawData->temperatureCRC        =   cmd[2];
//
//  rawData->rawRelativeHumidity   =   cmd[3];
//  rawData->rawRelativeHumidity <<=   8U;
//  rawData->rawRelativeHumidity  |=   cmd[4];
//
//  rawData->relativeHumidityCRC   =   cmd[5];
//
//
//
//  if ( aux == I2C_SUCCESS )
//  {
//      return   SHT4X_SUCCESS;
//  }
//  else
//  {
//      return   SHT4X_FAILURE;
//  }
//}
//
//
//
///**
// * @brief       SHT4X_ProccessData ( SHT4X_raw_data_t , SHT4X_final_data_t* )
// * @details     It clears the status register.
// *
// * @param[in]    myI2Cparameters: I2C parameters.
// * @param[in]    rawData:         Data to be processed.
// *
// * @param[out]   data:            Data result.
// *
// *
// * @return      N/A.
// *
// * @author      Karl Maxwell
// * @date        30/May/2022
// * @version     30/May/2022    The ORIGIN
// * @pre         N/A
// * @warning     N/A.
// */
//void  SHT4X_ProccessData ( SHT4X_raw_data_t rawData, SHT4X_final_data_t* data )
//{
//  /* Process the temperature value  */
//  data->temperature  =   ( -45.0 + ( 175.0 * ( rawData.rawTemperature / ( 65536.0 - 1.0 ) ) ) );
//
//  /* Process the relative humidity value  */
//  data->relativeHumidity  =   100.0 * ( rawData.rawRelativeHumidity / ( 65536.0 - 1.0 ) );
//}
