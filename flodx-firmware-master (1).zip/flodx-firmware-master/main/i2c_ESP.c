/**
 * @brief       i2c_ESP.c
 * @details     ESP-IDF I2C function libraries.
 *              Function file.
 *
 *
 * @return      N/A
 *
 * @author      Karl Maxwell
 * @date        12/May/2022
 * @version     12/May/2022    The ORIGIN
 * @pre         N/A
 * @warning     This file is ONLY for ESP-IDF devices.
 * @pre         This code belongs to AqueronteBlog ( http://unbarquero.blogspot.com ).
 */

#include <freertos/FreeRTOS.h>
#include "i2c_ESP.h"

static I2C_parameters_t stored_i2c_params;

/* Sets/updates i2c port configuration */
static void    i2c_config   ( I2C_parameters_t myI2Cparameters )
{
	if (myI2Cparameters.port != stored_i2c_params.port ||
		myI2Cparameters.SDA != stored_i2c_params.SDA ||
		myI2Cparameters.SDA_Pullup != stored_i2c_params.SDA_Pullup ||
		myI2Cparameters.SCL != stored_i2c_params.SCL ||
		myI2Cparameters.SCL_Pullup != stored_i2c_params.SCL_Pullup ||
		myI2Cparameters.I2C_Freq != stored_i2c_params.I2C_Freq) {

		i2c_config_t conf;
		conf.mode = I2C_MODE_MASTER;
		conf.sda_io_num = myI2Cparameters.SDA;
		conf.sda_pullup_en = myI2Cparameters.SDA_Pullup;
		conf.scl_io_num = myI2Cparameters.SCL;
		conf.scl_pullup_en = myI2Cparameters.SCL_Pullup;
		conf.master.clk_speed = myI2Cparameters.I2C_Freq;
		conf.clk_flags = I2C_SCLK_SRC_FLAG_FOR_NOMAL;
		i2c_param_config(myI2Cparameters.port, &conf);
	}
	stored_i2c_params = myI2Cparameters;
}

/**
 * @brief       i2c_init   ( I2C_parameters_t )
 * @details     It configures and installs the I2C peripheral.
 *
 * @param[in]    myI2Cparameters:       I2C parameters.
 *
 * @param[out]   Status of i2c_init.
 *
 *
 * @return      N/A
 *
 * @author      Karl Maxwell
 * @date        12/May/2022
 * @version     12/May/2022     The ORIGIN
 * @pre         I2C communication is by polling mode.
 * @warning     N/A.
 */
i2c_status_t    i2c_init   ( I2C_parameters_t myI2Cparameters )
{
	i2c_config(myI2Cparameters);
	return i2c_driver_install(myI2Cparameters.port, I2C_MODE_MASTER, 0, 0, 0);

    // Peripheral configures successfully
    return I2C_SUCCESS;
}



/**
 * @brief       i2c_write   ( I2C_parameters_t , uint8_t* , uint32_t , uint32_t  )
 * @details     Send data through I2C bus.
 *
 * @param[in]    myI2Cparameters:       I2C parameters.
 * @param[in]    *i2c_buff:             Data to be transmitted.
 * @param[in]    i2c_data_length:       Amount of data to be transmitted.
 * @param[in]    i2c_generate_stop:     Generate STOP bit or not.
 *
 * @param[out]   Status of i2c_write.
 *
 *
 * @return      N/A
 *
 * @author      Karl Maxwell
 * @date        12/May/2022
 * @version     12/May/2022         The ORIGIN
 * @pre         I2C communication is by polling mode.
 * @warning     N/A.
 */
i2c_status_t    i2c_write   ( I2C_parameters_t myI2Cparameters, uint8_t* i2c_buff, uint32_t i2c_data_length, uint32_t i2c_generate_stop )
{
	i2c_config(myI2Cparameters);

	i2c_cmd_handle_t cmd = i2c_cmd_link_create();
	i2c_master_start(cmd);
	i2c_master_write_byte(cmd, (myI2Cparameters.ADDR << 1) | I2C_WRITE, myI2Cparameters.ack_Check_Enable);
	i2c_master_write(cmd, i2c_buff, i2c_data_length, myI2Cparameters.ack_Check_Enable);
	if (i2c_generate_stop == I2C_STOP_BIT) {
		i2c_master_stop(cmd);
	}
	esp_err_t ret = i2c_master_cmd_begin(myI2Cparameters.port, cmd, I2C_TIMEOUT / portTICK_RATE_MS);
	i2c_cmd_link_delete(cmd);
	return ret == ESP_OK ? I2C_SUCCESS : I2C_FAILURE;
}



/**
 * @brief       i2c_read   ( I2C_parameters_t , uint8_t* , uint32_t )
 * @details     Read data through I2C bus.
 *
 * @param[in]    myI2Cparameters:   I2C parameters.
 * @param[in]    *i2c_buff:         Data to be transmitted.
 * @param[in]    i2c_data_length:   Amount of data to be transmitted.
 *
 * @param[out]   Status of i2c_read.
 *
 *
 * @return      N/A
 *
 * @author      Karl Maxwell
 * @date        12/May/2022
 * @version     12/May/2022         The ORIGIN
 * @pre         I2C communication is by polling mode.
 * @warning     N/A.
 */
i2c_status_t     i2c_read   ( I2C_parameters_t myI2Cparameters, uint8_t* i2c_buff, uint32_t i2c_data_length )
{
    if (i2c_data_length == 0) {
        return ESP_OK;
    }

    i2c_config(myI2Cparameters);

    i2c_cmd_handle_t cmd = i2c_cmd_link_create();
    i2c_master_start(cmd);
    i2c_master_write_byte(cmd, (myI2Cparameters.ADDR << 1) | I2C_READ, myI2Cparameters.ack_Check_Enable);
    if (i2c_data_length > 1) {
        i2c_master_read(cmd, i2c_buff, i2c_data_length - 1, I2C_MASTER_ACK);
    }
    i2c_master_read_byte(cmd, i2c_buff + i2c_data_length - 1, I2C_MASTER_NACK);
    i2c_master_stop(cmd);
    esp_err_t ret = i2c_master_cmd_begin(myI2Cparameters.port, cmd, I2C_TIMEOUT / portTICK_RATE_MS);
    i2c_cmd_link_delete(cmd);
    return ret;
}
