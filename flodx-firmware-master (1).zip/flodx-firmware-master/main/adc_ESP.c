/*
 * adc_ESP.c
 *
 *  Created on: 28 Jun 2022
 *      Author: Karl.Maxwell
 */

#include "adc_ESP.h"

void ADCInit(adc_parameters_t *adc_params) {
	//Configure ADC
	if (adc_params->unit == ADC_UNIT_1) {
		adc1_config_width(adc_params->bit_width);
		adc1_config_channel_atten(adc_params->channel, adc_params->atten);
	} else {
		adc2_config_channel_atten((adc2_channel_t)(adc_params->channel), adc_params->atten);
	}

	//Characterize ADC
	adc_params->adc_chars = calloc(1, sizeof(esp_adc_cal_characteristics_t));
	esp_adc_cal_characterize(adc_params->unit, adc_params->atten, adc_params->bit_width, adc_params->default_vref, adc_params->adc_chars);
}

void ADCRead(adc_parameters_t *adc_params, adc_reading_t *reading) {
	uint32_t adc_reading = 0;
	//Multisampling
	for (int i = 0; i < adc_params->no_of_samples; i++) {
		if (adc_params->unit == ADC_UNIT_1) {
			adc_reading += adc1_get_raw((adc1_channel_t)(adc_params->channel));
		} else {
			int raw;
			adc2_get_raw((adc2_channel_t)(adc_params->channel), adc_params->bit_width, &raw);
			adc_reading += raw;
		}
	}
	adc_reading /= adc_params->no_of_samples;
	reading->raw_reading = adc_reading;
	//Convert adc_reading to voltage in mV
	reading->voltage_mV = esp_adc_cal_raw_to_voltage(adc_reading, adc_params->adc_chars);
}
