/**
 * @brief       SHT4X.h
 * @details     Humidity and Temperature Sensor.
 *              Header file.
 *
 *
 * @return      N/A
 *
 * @author      Karl Maxwell
 * @date        30/May/2022
 * @version     30/May/2022    The ORIGIN
 * @pre         N/A
 * @warning     N/A
 * @pre         This code belongs to Nimbus Centre ( http://www.nimbus.cit.ie ).
 */


#include "stdint.h"
#include "i2c_ESP.h"


#ifndef SHT4X_H_
#define SHT4X_H_

#ifdef __cplusplus
extern "C" {
#endif


/**
  * @brief   DEFAULT ADDRESSES
  */
typedef enum
{
  SHT4X_ADDRESS_A     =   0x44,             /*!<   SHT4X ADDR pin connected to logic low   */
  SHT4X_ADDRESS_B     =   0x45              /*!<   SHT4X ADDR pin connected to logic high  */
} SHT4X_address_t;



typedef enum
{
	SHT4X_PRECISION_HIGH,
	SHT4X_PRECISION_MEDIUM,
	SHT4X_PRECISION_LOW
} SHT4X_precision_t;



typedef enum
{
  SHT4X_MEASURE_HIGH_PRECISION       = 0xFD,  /*!< measure T & RH with high precision (high repeatability)                         */
  SHT4X_MEASURE_MEDIUM_PRECISION     = 0xF6,  /*!< measure T & RH with medium precision (medium repeatability)                     */
  SHT4X_MEASURE_LOW_PRECISION        = 0xE0,  /*!< measure T & RH with lowest precision (low repeatability)                        */
  SHT4X_READ_SERIAL                  = 0x89,  /*!< read serial                                                                     */
  SHT4X_SOFT_RESET                   = 0x94,  /*!< soft reset                                                                      */
  SHT4X_ACTIVATE_HIGH_POWER_1S       = 0x39,  /*!< activate highest heater power & high precis. meas. (typ. 200mW @ 3.3V) for 1s   */
  SHT4X_ACTIVATE_HIGH_POWER_100MS    = 0x32,  /*!< activate highest heater power & high precis. meas. (typ. 200mW @ 3.3V) for 0.1s */
  SHT4X_ACTIVATE_MEDIUM_POWER_1S     = 0x2F,  /*!< activate medium heater power & high precis. meas. (typ. 110mW @ 3.3V) for 1s    */
  SHT4X_ACTIVATE_MEDIUM_POWER_100MS  = 0x24,  /*!< activate medium heater power & high precis. meas. (typ. 110mW @ 3.3V) for 0.1s  */
  SHT4X_ACTIVATE_LOW_POWER_1S        = 0x1E,  /*!< activate lowest heater power & high precis. meas. (typ. 20mW @ 3.3V) for 1s     */
  SHT4X_ACTIVATE_LOW_POWER_100MS     = 0x15   /*!< activate lowest heater power & high precis. meas. (typ. 20mW @ 3.3V) for 0.1s   */
} SHT4X_command_registers_t;



/* DATA: Temperature and Relative Humidity  */
typedef struct
{
	uint16_t rawTemperature;
	uint16_t rawRelativeHumidity;

	float temperature;
	float relativeHumidity;

	uint8_t  temperatureCRC;
	uint8_t  relativeHumidityCRC;
} SHT4X_data_t;


/**
  * @brief   INTERNAL CONSTANTS
  */
typedef enum
{
    SHT4X_SUCCESS     =       0,
    SHT4X_FAILURE     =       1
} SHT4X_status_t;



/**
  * @brief   FUNCTION PROTOTYPES
  */
/** It configures the I2C peripheral.
  */
SHT4X_status_t  SHT4X_Init    ( I2C_parameters_t myI2Cparameters                                               );

/** It triggers a reading of temperature and relative humidity.
  */
SHT4X_status_t  SHT4X_StartMeasureTAndRH    ( I2C_parameters_t myI2Cparameters, SHT4X_precision_t precision    );

/** It returns the temperature and relative humidity. SHT4X_StartMeasureTAndRH must be called first
  */
SHT4X_status_t  SHT4X_GetDataTAndRH    ( I2C_parameters_t myI2Cparameters, SHT4X_data_t* data 				   );

/** It perfoms a software reset.
  */
SHT4X_status_t  SHT4X_SetSoftReset    ( I2C_parameters_t myI2Cparameters                                       );


#ifdef __cplusplus
}
#endif

#endif /* SHT4X_H */
