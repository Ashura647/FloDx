/* SoftAP based Provisioning Example

   This example code is in the Public Domain (or CC0 licensed, at your option.)

   Unless required by applicable law or agreed to in writing, this
   software is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
   CONDITIONS OF ANY KIND, either express or implied.
*/

#include <string.h>
#include <math.h>

#include <driver/gpio.h>
#include <driver/rtc_io.h>
#include <driver/timer.h>
#include <esp_event.h>
#include <esp_log.h>
#include <esp_sleep.h>
#include <esp_system.h>
#include <esp_wifi.h>
#include <esp32/rom/uart.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <lwip/err.h>
#include <lwip/sys.h>
#include <mqtt_client.h>
#include <nvs_flash.h>
#include <SHT4X.h>
#include "adc_ESP.h"

#include "app_prov.h"
#include "nvm.h"
#include "BH1790GLC.h"

#define USE_HARDCODED_SSID true

#define HARDCODED_SSID		"FloDX_router"
#define HARDCODED_PASSWORD  "flodx123456"

#define ESP_INTR_FLAG_DEFAULT 0

#define RESET_BUTTON_HOLD_TIME_US  60000000
#define SWITCH_RECENT_TIME_US        250000

#define UPLOAD_PERIOD_ACTIVE_S     		 60

#define I2C_MASTER_SCL_IO         GPIO_NUM_22  /*!< gpio number for I2C master clock */
#define I2C_MASTER_SDA_IO         GPIO_NUM_21  /*!< gpio number for I2C master data  */
#define I2C_MASTER_NUM              I2C_NUM_1  /*!< I2C port number for master dev */
#define I2C_MASTER_FREQ_HZ             400000  /*!< I2C master clock frequency */
#define I2C_MASTER_TX_BUF_DISABLE           0  /*!< I2C master doesn't need buffer */
#define I2C_MASTER_RX_BUF_DISABLE           0  /*!< I2C master doesn't need buffer */

#define SWITCH_OUT_IO    GPIO_NUM_12
#define SWITCH_IN_IO     GPIO_NUM_4
#define SWITCH_RED_IO    GPIO_NUM_19
#define SWITCH_GREEN_IO  GPIO_NUM_2
#define SWITCH_BLUE_IO   GPIO_NUM_13
#define BH1790_1_EN_IO   GPIO_NUM_25
#define BH1790_2_EN_IO   GPIO_NUM_0
#define BH1790_3_EN_IO   GPIO_NUM_26
#define BH1790_4_EN_IO   GPIO_NUM_14
#define LED_PWR_IO       GPIO_NUM_18

#define ACCESS_TOKEN_LEN 20

#define DEVICE_CLAIMING_WINDOW_MS 600000

#define NO_OF_OD_READINGS_TO_AVG 30

#define BATTERY_MAX_READING 2500
#define BATTERY_MIN_READING 1750

#define SENSOR_COUNT 4

typedef enum {
	WIFI_SETUP_STATE,
	ENTER_CHARGING_STATE,
	CHARGING_STATE,
	ENTER_ACTIVE_STATE,
	ACTIVE_STATE,
	ENTER_INACTIVE_STATE,
	INACTIVE_STATE,
	ENTER_DISCONNECTED_STATE,
	DISCONNECTED_STATE
} SYSTEM_STATE;

SYSTEM_STATE system_state = WIFI_SETUP_STATE;

typedef enum {
	ENTER_ALARM_STATE_0,
	ALARM_STATE_0,
	ENTER_ALARM_STATE_1,
	ALARM_STATE_1,
	ENTER_ALARM_STATE_2,
	ALARM_STATE_2
} ALARM_STATE;

ALARM_STATE alarm_state = ENTER_ALARM_STATE_0;

static xQueueHandle gpio_evt_queue = NULL;

typedef enum {
	BH1790GLC_POWER_OFF = 0,
	BH1790GLC_POWER_ON = 1
} t_BH1790GLC_power_level;

typedef enum {
	SWITCH_COLOUR_OFF,
	SWITCH_COLOUR_RED,
	SWITCH_COLOUR_BLUE,
	SWITCH_COLOUR_GREEN,
	SWITCH_COLOUR_YELLOW,
	SWITCH_COLOUR_MAGENTA,
	SWITCH_COLOUR_CYAN,
	SWITCH_COLOUR_WHITE,
} t_switch_colour;

typedef enum {
	WIFI_CONNECTION_STATE_UNKNOWN,
	WIFI_DISCONNECTED,
	WIFI_CONNECTED
} t_wifi_state;

t_wifi_state wifi_state = WIFI_CONNECTION_STATE_UNKNOWN;

bool flag_wifi_preprovisioned;
bool flag_got_ip;
bool flag_mqtt_publish_successful = true;
bool flag_thingsboard_provisioning_complete = false;

bool flag_enter_active_state   = false;
bool flag_enter_inactive_state = false;

bool flag_switch_recently_pressed = false;

static esp_timer_handle_t reset_button_timer;
static esp_timer_handle_t switch_recently_pressed_timer;

esp_mqtt_client_handle_t mqtt_client;


static const char MQTT_BROKER_URL[]          = "mqtt://thingsboard.cloud";
static const char MQTT_TOPIC[]               =  "v1/devices/me/telemetry";
static const char PROVISION_DEVICE_KEY[]     =     "ipp2mav413zbqux8k47i";
static const char PROVISION_DEVICE_SECRET[]  =     "bbx27wwihgmd6qlyc8vh";
static const char PROVISION_REQUEST_TOPIC[]  = 		 "/provision/request";
static const char PROVISION_RESPONSE_TOPIC[] =      "/provision/response";
static const char PROVISION_USERNAME[]       = 			      "provision";
static const char CLAIM_TOPIC[]              =      "v1/devices/me/claim";

char access_token[ACCESS_TOKEN_LEN + 1] = {0};

char mac_address[18] = {};

I2C_parameters_t    myBH1790GLC_I2C_parameters;
BH1790GLC_data_t 	myBH1790GLC_data;
BH1790GLC_status_t  myBH1790GLC_result;
I2C_parameters_t    mySHT4X_I2C_parameters;
SHT4X_data_t        mySHT4X_data;
SHT4X_status_t      mySHT4X_result;

adc_parameters_t adc_params = {
	.unit = ADC_UNIT_1,
	.channel = ADC_CHANNEL_6,
	.atten = ADC_ATTEN_DB_11,
	.bit_width = ADC_WIDTH_BIT_12,
	.default_vref = 1650,
	.no_of_samples = 64
};

adc_reading_t adc_reading;

static const char *TAG = "app";

esp_err_t publish_mqtt_data(char * data_str);
esp_err_t thingsboard_provision_device(char * device_name);
esp_err_t start_claiming_window();
void InitTimers();
void InitGPIOOutputs();
void InitGPIOInterrupts();
void RunSoftAP();
void GetMacAddress();
void SetSwitchColour(t_switch_colour colour);
void PowerOnOffBH1790GLC(uint8_t sensor_num, t_BH1790GLC_power_level power_level);
bool ReadBH1790GLC(uint8_t sensor_num, float * reading);
void InitSensors();

static void WifiStaEventHandler(void* arg, esp_event_base_t event_base,
                          int event_id, void* event_data)
{
	if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_START) {
		esp_wifi_connect();
	} else if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_DISCONNECTED) {
		wifi_state = WIFI_DISCONNECTED;
		SetSwitchColour(SWITCH_COLOUR_RED);printf("RED %u\n", __LINE__);
		ESP_LOGI(TAG,"connect to the AP fail");
		esp_wifi_connect();
		ESP_LOGI(TAG, "retry to connect to the AP");
	} else if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_CONNECTED) {
		wifi_state = WIFI_CONNECTED;
	} else if (event_base == IP_EVENT && event_id == IP_EVENT_STA_GOT_IP) {
		wifi_state = WIFI_CONNECTED;
		SetSwitchColour(SWITCH_COLOUR_OFF);printf("OFF %u\n", __LINE__);
		ip_event_got_ip_t* event = (ip_event_got_ip_t*) event_data;
		ESP_LOGI(TAG, "got ip:%s",
				 ip4addr_ntoa(&event->ip_info.ip));
		flag_got_ip = true;
	}
}

static void WifiInitSta()
{printf("\n!! WifiInitSta\n");
    /* Set our event handling */
    ESP_ERROR_CHECK(esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID, WifiStaEventHandler, NULL));
    ESP_ERROR_CHECK(esp_event_handler_register(IP_EVENT, IP_EVENT_STA_GOT_IP, WifiStaEventHandler, NULL));

    /* Start Wi-Fi in station mode with credentials set during provisioning (or hardcoded) */
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_start());
}

static void StartSoftAPProvisioning()
{
    /* Security version */
    int security = 0;
    /* Proof of possession */
    const protocomm_security_pop_t *pop = NULL;

#ifdef CONFIG_EXAMPLE_USE_SEC_1
    security = 1;
#endif

    /* Having proof of possession is optional */
#ifdef CONFIG_EXAMPLE_USE_POP
    const static protocomm_security_pop_t app_pop = {
        .data = (uint8_t *) CONFIG_EXAMPLE_POP,
        .len = (sizeof(CONFIG_EXAMPLE_POP)-1)
    };
    pop = &app_pop;
#endif

        const char *ssid = NULL;

#ifdef CONFIG_EXAMPLE_SSID
        ssid = CONFIG_EXAMPLE_SSID;
#else
        uint8_t eth_mac[6];
        esp_wifi_get_mac(WIFI_IF_STA, eth_mac);

        char ssid_with_mac[24];
        sprintf(ssid_with_mac, "FLODX_%s", mac_address);

        ssid = ssid_with_mac;
#endif

    ESP_ERROR_CHECK(app_prov_start_softap_provisioning(
        ssid, CONFIG_EXAMPLE_PASS, security, pop));
}

static void IRAM_ATTR gpio_isr_handler(void* arg)
{
    uint32_t gpio_num = (uint32_t) arg;
    xQueueSendFromISR(gpio_evt_queue, &gpio_num, NULL);
}

static void gpio_task(void* arg)
{
    uint32_t io_num;
    for(;;) {
        if(xQueueReceive(gpio_evt_queue, &io_num, portMAX_DELAY)) {
        	if (io_num == SWITCH_IN_IO) {
            	if (gpio_get_level(io_num) == 1) {
            		esp_timer_stop(reset_button_timer);
					ESP_ERROR_CHECK(esp_timer_start_once(reset_button_timer, RESET_BUTTON_HOLD_TIME_US));

            		if (system_state != WIFI_SETUP_STATE && flag_switch_recently_pressed == false) {
						flag_switch_recently_pressed = true;
						esp_timer_stop(switch_recently_pressed_timer);
						ESP_ERROR_CHECK(esp_timer_start_once(switch_recently_pressed_timer, SWITCH_RECENT_TIME_US));

						ESP_LOGI(TAG, "Switch interrupt triggered");
						switch (system_state) {
						case ENTER_INACTIVE_STATE:
						case INACTIVE_STATE:
							SetSwitchColour(SWITCH_COLOUR_GREEN);printf("GREEN %u\n", __LINE__);
							flag_enter_active_state = true;
							break;
						case ENTER_ACTIVE_STATE:
						case ACTIVE_STATE:
							SetSwitchColour(SWITCH_COLOUR_OFF);printf("OFF %u\n", __LINE__);
							flag_enter_inactive_state = true;
							break;
						default:
							break;
						};
            		}
            	} else {
            		esp_timer_stop(reset_button_timer);
            	}
            }
        }
        vTaskDelay(1);
    }
}

static esp_err_t mqtt_event_handler_cb(esp_mqtt_event_handle_t event)
{
    mqtt_client = event->client;
    int msg_id;
    // your_context_t *context = event->context;
    switch (event->event_id) {
        case MQTT_EVENT_CONNECTED:
        	if (!flag_thingsboard_provisioning_complete) {
        		msg_id = esp_mqtt_client_subscribe(mqtt_client, PROVISION_RESPONSE_TOPIC, 0);
        		ESP_LOGI(TAG, "sent subscribe successful, msg_id=%d", msg_id);
        	}
            ESP_LOGI(TAG, "MQTT_EVENT_CONNECTED");
            break;
        case MQTT_EVENT_DISCONNECTED:
            ESP_LOGI(TAG, "MQTT_EVENT_DISCONNECTED");
            break;
        case MQTT_EVENT_SUBSCRIBED:
            ESP_LOGI(TAG, "MQTT_EVENT_SUBSCRIBED, msg_id=%d", event->msg_id);
            break;
        case MQTT_EVENT_UNSUBSCRIBED:
            ESP_LOGI(TAG, "MQTT_EVENT_UNSUBSCRIBED, msg_id=%d", event->msg_id);
            break;
        case MQTT_EVENT_PUBLISHED:
            ESP_LOGI(TAG, "MQTT_EVENT_PUBLISHED, msg_id=%d", event->msg_id);
            break;
        case MQTT_EVENT_DATA:
            ESP_LOGI(TAG, "MQTT_EVENT_DATA");
            if ((strcmp(event->topic, PROVISION_REQUEST_TOPIC) == 0) || (strcmp(event->topic, MQTT_TOPIC) == 0) || (strcmp(event->topic, CLAIM_TOPIC) == 0)) {
            	printf("TOPIC=%s\n", event->topic);
				printf("DATA=%s\n", event->data);
            	msg_id = esp_mqtt_client_publish(mqtt_client, event->topic, event->data, 0, 1, 0);
            	ESP_LOGI(TAG, "sent publish successful, msg_id=%d", msg_id);
            	flag_mqtt_publish_successful = true;
            } else if (strcmp(event->topic, PROVISION_RESPONSE_TOPIC) == 0) {
            	ESP_LOGI(TAG, "Received response to provision request");
            	int data_str_max_len  = 100;
            	char data_str[data_str_max_len + 1];
            	snprintf(data_str , (event->data_len  + 1 < data_str_max_len  ? event->data_len  + 1: data_str_max_len ), "%s", event->data );
				printf("DATA=%s\n", data_str);
				if (strstr(data_str, "credentialsValue") != NULL) {
					snprintf(access_token, ACCESS_TOKEN_LEN + 1, "%s", &data_str[21]);  // Copy credentialsValue from data, starts at 21st character
					nvm_write_value("access_token", access_token, 20);
					flag_thingsboard_provisioning_complete = true;
				}

            } else {
            	ESP_LOGI(TAG, "Unrecognised topic");
            }
            break;
        case MQTT_EVENT_ERROR:
            ESP_LOGI(TAG, "MQTT_EVENT_ERROR");
            break;
        default:
            ESP_LOGI(TAG, "Other event id:%d", event->event_id);
            break;
    }
    return ESP_OK;
}

static void mqtt_event_handler(void *handler_args, esp_event_base_t base, int32_t event_id, void *event_data) {
    ESP_LOGD(TAG, "Event dispatched from event loop base=%s, event_id=%d", base, event_id);
    mqtt_event_handler_cb(event_data);
}

static void mqtt_provision_app_start(void)
{
    esp_mqtt_client_config_t mqtt_cfg = {
        .uri = MQTT_BROKER_URL,
		.username = PROVISION_USERNAME
    };

    mqtt_client = esp_mqtt_client_init(&mqtt_cfg);
    esp_mqtt_client_register_event(mqtt_client, ESP_EVENT_ANY_ID, mqtt_event_handler, mqtt_client);
    esp_mqtt_client_start(mqtt_client);
}

static void mqtt_app_start(void)
{
    esp_mqtt_client_config_t mqtt_cfg = {
        .uri = MQTT_BROKER_URL,
		.username = access_token
    };

    mqtt_client = esp_mqtt_client_init(&mqtt_cfg);
    esp_mqtt_client_register_event(mqtt_client, ESP_EVENT_ANY_ID, mqtt_event_handler, mqtt_client);
    esp_mqtt_client_start(mqtt_client);
}

esp_err_t publish_mqtt_data(char * data_str) {
	esp_mqtt_event_t event = {
		.event_id = MQTT_EVENT_DATA,
		.client = mqtt_client,
		.topic = (char*)MQTT_TOPIC,
		.topic_len = strlen(MQTT_TOPIC),
		.data = data_str,
		.data_len = strlen(data_str)
	};
	return mqtt_event_handler_cb(&event);
}

esp_err_t thingsboard_provision_device(char * device_name) {
	char data_str[126];
	sprintf(data_str, "{\"deviceName\":\"%s\",\"provisionDeviceKey\":\"%s\",\"provisionDeviceSecret\":\"%s\"}", device_name, (char*)PROVISION_DEVICE_KEY, (char*)PROVISION_DEVICE_SECRET);
	esp_mqtt_event_t event = {
		.event_id = MQTT_EVENT_DATA,
		.client = mqtt_client,
		.topic = (char*)PROVISION_REQUEST_TOPIC,
		.data = data_str
	};
	return mqtt_event_handler_cb(&event);
}

esp_err_t start_claiming_window() {
	char data_str[25];
	sprintf(data_str, "{\"durationMs\":\"%u\"}", DEVICE_CLAIMING_WINDOW_MS);
	esp_mqtt_event_t event = {
		.event_id = MQTT_EVENT_DATA,
		.client = mqtt_client,
		.topic = (char*)CLAIM_TOPIC,
		.data = data_str
	};
	return mqtt_event_handler_cb(&event);
}

static void ResetButtonTimerCallback (void* arg)
{
	// Erase all data in NVM
	nvs_flash_erase();

	// Turn off LED power
	gpio_set_level(LED_PWR_IO, 0);

	// Turn switch light off momentarily
	SetSwitchColour(SWITCH_COLOUR_OFF);
	vTaskDelay(500 / portTICK_RATE_MS);

	// Restart ESP
	esp_restart();
}

static void SwitchRecentTimerCallback (void* arg)
{
	flag_switch_recently_pressed = false;
}

void InitTimers()
{
	// Create timer for reset button
	const esp_timer_create_args_t reset_button_timer_args = {
			.callback = &ResetButtonTimerCallback,
			.name = "reset-button"
	};
	ESP_ERROR_CHECK(esp_timer_create(&reset_button_timer_args, &reset_button_timer));

	// Create timer for preventing double trigger of switch
	const esp_timer_create_args_t switch_recently_pressed_timer_args = {
			.callback = &SwitchRecentTimerCallback,
			.name = "switch"
	};
	ESP_ERROR_CHECK(esp_timer_create(&switch_recently_pressed_timer_args, &switch_recently_pressed_timer));
}

void InitGPIOOutputs()
{
	gpio_config_t gpio_cfg;
	gpio_cfg.pin_bit_mask  = BIT64(BH1790_1_EN_IO) | BIT64(BH1790_2_EN_IO) | BIT64(BH1790_3_EN_IO) | BIT64(BH1790_4_EN_IO);
	gpio_cfg.pin_bit_mask |= BIT64(LED_PWR_IO);
	gpio_cfg.pin_bit_mask |= BIT64(SWITCH_RED_IO) | BIT64(SWITCH_GREEN_IO) | BIT64(SWITCH_BLUE_IO);
	gpio_cfg.pin_bit_mask |= BIT64(SWITCH_OUT_IO);
	gpio_cfg.mode          = GPIO_MODE_OUTPUT;
	gpio_cfg.pull_up_en    = GPIO_PULLUP_DISABLE;
	gpio_cfg.pull_down_en  = GPIO_PULLDOWN_DISABLE;
	gpio_cfg.intr_type     = GPIO_INTR_DISABLE;
	gpio_config(&gpio_cfg);

	// Set switch output high (while switch is pressed, this high level will be transferred to SWITCH_IN_IO)
	gpio_set_level(SWITCH_OUT_IO, 1);
}

void InitADCInputs()
{
	ADCInit(&adc_params);
}

void InitGPIOInterrupts()
{
	// Configure switch GPIO
	gpio_config_t gpio_cfg;
	gpio_cfg.pin_bit_mask = BIT64(SWITCH_IN_IO);
	gpio_cfg.mode         = GPIO_MODE_INPUT;
	gpio_cfg.pull_up_en   = GPIO_PULLUP_DISABLE;
	gpio_cfg.pull_down_en = GPIO_PULLDOWN_ENABLE;
	gpio_cfg.intr_type    = GPIO_INTR_ANYEDGE;
	gpio_config(&gpio_cfg);

	// Install gpio isr service
	gpio_install_isr_service(ESP_INTR_FLAG_DEFAULT);
	// Hook isr handler for specific gpio pins
	gpio_isr_handler_add(SWITCH_IN_IO, gpio_isr_handler, (void*) SWITCH_IN_IO);

	// Create a queue to handle gpio event from isr
	gpio_evt_queue = xQueueCreate(10, sizeof(uint32_t));
	// Start gpio task
	xTaskCreate(gpio_task, "gpio_task", 2048, NULL, 10, NULL);
}

void RunSoftAP()
{
	/* Initialize networking stack */
	tcpip_adapter_init();

	/* Create default event loop needed by the
	 * main app and the provisioning service */
	ESP_ERROR_CHECK(esp_event_loop_create_default());

	/* Initialize NVS needed by Wi-Fi */
	ESP_ERROR_CHECK(nvs_flash_init());

	/* Initialize Wi-Fi with default config */
	wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
	ESP_ERROR_CHECK(esp_wifi_init(&cfg));

	/* Check if device is provisioned */
	if (USE_HARDCODED_SSID == false) {
		if (app_prov_is_provisioned(&flag_wifi_preprovisioned) != ESP_OK) {
			ESP_LOGE(TAG, "Error getting device provisioning state");
			return;
		}
	} else {
		/* Set hardcoded credentials */
		flag_wifi_preprovisioned = true;
		if (set_ssid_and_password(HARDCODED_SSID, HARDCODED_PASSWORD) != ESP_OK) {
			ESP_LOGE(TAG, "Error setting hardcoded SSID and password");
			return;
		}
	}

	if (flag_wifi_preprovisioned == false) {
		/* If not provisioned, start provisioning via soft AP */
		ESP_LOGI(TAG, "Starting WiFi SoftAP provisioning");
		SetSwitchColour(SWITCH_COLOUR_BLUE);printf("BLUE %u\n", __LINE__);
		StartSoftAPProvisioning();
	} else {
		/* Start WiFi station with credentials set during provisioning */
		ESP_LOGI(TAG, "Starting WiFi station");
		WifiInitSta();
	}
}

void GetMacAddress()
{
	uint8_t mac_bytes[6];
	esp_read_mac(mac_bytes, ESP_MAC_WIFI_STA);

	sprintf(mac_address, "%02X:%02X:%02X:%02X:%02X:%02X",
			mac_bytes[0], mac_bytes[1], mac_bytes[2], mac_bytes[3], mac_bytes[4], mac_bytes[5]);
	printf("%s\n", mac_address);
}

void SetSwitchColour(t_switch_colour colour)
{
	switch (colour) {
	case SWITCH_COLOUR_OFF:
		gpio_set_level(SWITCH_RED_IO  , 0);
		gpio_set_level(SWITCH_GREEN_IO, 0);
		gpio_set_level(SWITCH_BLUE_IO , 0);
		break;
	case SWITCH_COLOUR_RED:
		gpio_set_level(SWITCH_RED_IO  , 1);
		gpio_set_level(SWITCH_GREEN_IO, 0);
		gpio_set_level(SWITCH_BLUE_IO , 0);
		break;
	case SWITCH_COLOUR_GREEN:
		gpio_set_level(SWITCH_RED_IO  , 0);
		gpio_set_level(SWITCH_GREEN_IO, 1);
		gpio_set_level(SWITCH_BLUE_IO , 0);
		break;
	case SWITCH_COLOUR_BLUE:
		gpio_set_level(SWITCH_RED_IO  , 0);
		gpio_set_level(SWITCH_GREEN_IO, 0);
		gpio_set_level(SWITCH_BLUE_IO , 1);
		break;
	case SWITCH_COLOUR_YELLOW:
		gpio_set_level(SWITCH_RED_IO  , 1);
		gpio_set_level(SWITCH_GREEN_IO, 1);
		gpio_set_level(SWITCH_BLUE_IO , 0);
		break;
	case SWITCH_COLOUR_MAGENTA:
		gpio_set_level(SWITCH_RED_IO  , 1);
		gpio_set_level(SWITCH_GREEN_IO, 0);
		gpio_set_level(SWITCH_BLUE_IO , 1);
		break;
	case SWITCH_COLOUR_CYAN:
		gpio_set_level(SWITCH_RED_IO  , 0);
		gpio_set_level(SWITCH_GREEN_IO, 1);
		gpio_set_level(SWITCH_BLUE_IO , 1);
		break;
	case SWITCH_COLOUR_WHITE:
		gpio_set_level(SWITCH_RED_IO  , 1);
		gpio_set_level(SWITCH_GREEN_IO, 1);
		gpio_set_level(SWITCH_BLUE_IO , 1);
		break;
	default:
		break;
	};
}

void PowerOnOffBH1790GLC(uint8_t sensor_num, t_BH1790GLC_power_level power_level)
{
	switch (sensor_num) {
	case 1:
		gpio_set_level(BH1790_1_EN_IO, power_level);
		break;
	case 2:
		gpio_set_level(BH1790_2_EN_IO, power_level);
		break;
	case 3:
		gpio_set_level(BH1790_3_EN_IO, power_level);
		break;
	case 4:
		gpio_set_level(BH1790_4_EN_IO, power_level);
		break;
	default:
		break;
	};
}

bool ReadBH1790GLC(uint8_t sensor_num, float * reading)
{
	float temp_reading = 0;
	uint8_t retries = 10;

	PowerOnOffBH1790GLC(sensor_num, BH1790GLC_POWER_ON);

//	/* !! Maybe we need to wait here !! */
	vTaskDelay(50 / portTICK_RATE_MS);

	do {
		myBH1790GLC_result = BH1790GLC_StartMeasurement(myBH1790GLC_I2C_parameters, myBH1790GLC_data);

		if (myBH1790GLC_result != BH1790GLC_SUCCESS) {
			retries--;
		} else {
//			printf ("BH1790GLC_StartMeasurement success\n");
		}
	} while (myBH1790GLC_result != BH1790GLC_SUCCESS && retries > 0);

	if (myBH1790GLC_result != BH1790GLC_SUCCESS) {
		ESP_LOGE(TAG, "Failed to start BH1790GLC %u measurement, retries exhausted", sensor_num);
	} else {
		for (int i = 0; i < NO_OF_OD_READINGS_TO_AVG; i++) {
			vTaskDelay(50 / portTICK_RATE_MS);
			myBH1790GLC_result |= BH1790GLC_GetRawDataOut(myBH1790GLC_I2C_parameters, &myBH1790GLC_data);
			if (myBH1790GLC_result != BH1790GLC_SUCCESS) {
				if (retries > 0) {
					if (i >= 0) {
						i--;
					}
					retries--;
				} else {
					ESP_LOGE(TAG, "Failed to read BH1790GLC %u, retries exhausted", sensor_num);
					break;
				}
			}
			temp_reading += (float)(myBH1790GLC_data.dataOut_LED_OFF) / NO_OF_OD_READINGS_TO_AVG;
//			if (myBH1790GLC_result == BH1790GLC_SUCCESS) printf("%d : %u\n", i, myBH1790GLC_data.dataOut_LED_OFF);
		}
	}

	PowerOnOffBH1790GLC(sensor_num, BH1790GLC_POWER_OFF);

	if (myBH1790GLC_result == BH1790GLC_SUCCESS) {
//		ESP_LOGI(TAG, "BH1790GLC %u reading: %f", sensor_num, temp_reading);
		*reading = temp_reading;
	}
	return myBH1790GLC_result == BH1790GLC_SUCCESS ? true : false;
}

bool ReadSHT4X(float * temperature, float * relative_humidity)
{
	mySHT4X_result = SHT4X_StartMeasureTAndRH     ( mySHT4X_I2C_parameters, SHT4X_PRECISION_HIGH );

	vTaskDelay(15 / portTICK_RATE_MS);

	mySHT4X_result |= SHT4X_GetDataTAndRH     ( mySHT4X_I2C_parameters,  &mySHT4X_data );

	if (mySHT4X_result == SHT4X_SUCCESS) {
		ESP_LOGI(TAG, "SHT4X reading: T - %f C, RH - %f %%", mySHT4X_data.temperature, mySHT4X_data.relativeHumidity);
		*temperature = mySHT4X_data.temperature;
		*relative_humidity = mySHT4X_data.relativeHumidity;
	} else {
		ESP_LOGE(TAG, "Failed to read SHT4X");
	}

	return mySHT4X_result == SHT4X_SUCCESS ? true : false;
}

void InitSensors()
{
	/* I2C definition   */
	myBH1790GLC_I2C_parameters.port = I2C_MASTER_NUM;
	myBH1790GLC_I2C_parameters.SDA = I2C_MASTER_SDA_IO;
	myBH1790GLC_I2C_parameters.SCL = I2C_MASTER_SCL_IO;
	myBH1790GLC_I2C_parameters.SDA_Pullup = GPIO_PULLUP_ENABLE;
	myBH1790GLC_I2C_parameters.SCL_Pullup = GPIO_PULLUP_ENABLE;
	myBH1790GLC_I2C_parameters.I2C_Freq = I2C_MASTER_FREQ_HZ;
	myBH1790GLC_I2C_parameters.ADDR = BH1790GLC_ADDRESS;
	myBH1790GLC_I2C_parameters.ack_Check_Enable = true;

	/* Use same I2C parameters for SHT4x   */
	mySHT4X_I2C_parameters.port              =    myBH1790GLC_I2C_parameters.port;
	mySHT4X_I2C_parameters.SDA               =    myBH1790GLC_I2C_parameters.SDA;
	mySHT4X_I2C_parameters.SCL               =    myBH1790GLC_I2C_parameters.SCL;
	mySHT4X_I2C_parameters.SDA_Pullup        =    myBH1790GLC_I2C_parameters.SDA_Pullup;
	mySHT4X_I2C_parameters.SCL_Pullup        =    myBH1790GLC_I2C_parameters.SCL_Pullup;
	mySHT4X_I2C_parameters.I2C_Freq          =    myBH1790GLC_I2C_parameters.I2C_Freq;
	mySHT4X_I2C_parameters.ack_Check_Enable  =    myBH1790GLC_I2C_parameters.ack_Check_Enable;

	/* Give SHT4x its own I2C address */
	mySHT4X_I2C_parameters.ADDR              =    SHT4X_ADDRESS_A;

	/* Configure I2C peripheral  */
	i2c_init    ( myBH1790GLC_I2C_parameters );

	/* Configure the BH1790GLC system control setting	 */
	myBH1790GLC_data.rdy				 =	 MEAS_CONTROL1_RDY_OSC_BLOCK_ACTIVE;
	myBH1790GLC_data.led_lighting_freq	 =	 MEAS_CONTROL1_LED_LIGHTING_FREQ_64HZ_MODE;
	myBH1790GLC_data.rcycle				 =	 MEAS_CONTROL1_RCYCLE_32HZ_MODE;

	/* Configure the BH1790GLC measurement control setting	 */
	myBH1790GLC_data.led_en	 	    =	 MEAS_CONTROL2_LED_EN_0;
	myBH1790GLC_data.led_on_time	=	 MEAS_CONTROL2_LED_ON_TIME_0_6_MS_MODE;
	myBH1790GLC_data.led_current	=	 MEAS_CONTROL2_LED_CURRENT_1_MA_MODE;
}

void app_main()
{
//	// POTENTIOMETER TEST CODE
//	InitGPIOOutputs();
//	InitSensors();
//	gpio_set_level(LED_PWR_IO, 1);
//	PowerOnOffBH1790GLC(1, BH1790GLC_POWER_ON);

// // BH1790 TEST CODE
//	InitGPIOOutputs();
//	InitSensors();
//	float readings[SENSOR_COUNT] = {0.0};
//	while (1) {
//		gpio_set_level(LED_PWR_IO, 1);
//
//		for (uint8_t sensor_num = 1; sensor_num <= SENSOR_COUNT; sensor_num++) {
//			if (!ReadBH1790GLC(sensor_num, &readings[sensor_num - 1])) {
//				readings[sensor_num - 1] = 0;
//			}
//		}
//		gpio_set_level(LED_PWR_IO, 0);
//
//		printf("%5.0f, %5.0f, %5.0f, %5.0f\n", readings[0], readings[1], readings[2], readings[3]);
//	}

// RAW BATTERY TEST CODE
//	ADCInit(&adc_params);
//	while (1) {
//		ADCRead(&adc_params, &adc_reading);
//		printf("Raw: %d\tVoltage: %dmV\n", adc_reading.raw_reading, adc_reading.voltage_mV);
//		vTaskDelay(500 / portTICK_RATE_MS);
//	}

	GetMacAddress();

	InitGPIOOutputs();
	InitADCInputs();
	InitGPIOInterrupts();
	InitTimers();

	RunSoftAP();

	/* Wait for IP assignment */
	printf("Waiting for IP assignment\n");

	while (flag_got_ip == false) {
		if (!flag_wifi_preprovisioned) {
			wifi_prov_sta_state_t prov_state;
			if (app_prov_get_wifi_state(&prov_state) == ESP_OK) {
				if (prov_state == WIFI_PROV_STA_CONNECTED) {
					flag_got_ip = true;
				} else if (prov_state == WIFI_PROV_STA_DISCONNECTED) {
					SetSwitchColour(SWITCH_COLOUR_RED);printf("RED %u\n", __LINE__);
				}
			}
		}
		vTaskDelay(1);
	};

	SetSwitchColour(SWITCH_COLOUR_YELLOW);printf("YELLOW %u\n", __LINE__);

	printf("IP assigned\n");

	InitSensors();

	char value_str[21] = "";
	esp_err_t ret = nvm_read_value("access_token", &value_str, 20);
	if (ret == ESP_OK) {
		sprintf(access_token, value_str);
		flag_thingsboard_provisioning_complete = true;
		ESP_LOGI(TAG, "Retrieved access token from NVM");
	}

	if (!flag_thingsboard_provisioning_complete) {
		ESP_LOGI(TAG, "Provisioning device on Thingsboard");
		mqtt_provision_app_start();
		while (!flag_thingsboard_provisioning_complete) {
			thingsboard_provision_device(mac_address);
			vTaskDelay(1000 / portTICK_RATE_MS);
			if (!flag_thingsboard_provisioning_complete) {
				SetSwitchColour(SWITCH_COLOUR_RED);printf("RED %u\n", __LINE__);
				ESP_LOGI(TAG, "Device provisioning failed. Retrying in 30 seconds");
				vTaskDelay(30000 / portTICK_RATE_MS);
			}
		}
		esp_mqtt_client_stop(mqtt_client);
		ESP_LOGI(TAG, "Device provisioning successful");
		SetSwitchColour(SWITCH_COLOUR_OFF);printf("OFF %u\n", __LINE__);

		mqtt_app_start();

		ESP_LOGI(TAG, "Opening 10 minute window to claim device");
		start_claiming_window();
		while (!flag_mqtt_publish_successful) {}
	} else {
		mqtt_app_start();
	}

	uint32_t upload_time_last = 0;

	bool od_successes[SENSOR_COUNT] = {false};
	float od_readings[SENSOR_COUNT] = {0};
	bool temperature_success = false;
	float temperature = 0;
	float relative_humidity = 0;
	uint32_t battery_level = 0;

	char data_str[512] = {0};

	vTaskDelay(10000 / portTICK_RATE_MS);

	SetSwitchColour(SWITCH_COLOUR_OFF);printf("OFF %u\n", __LINE__);

	system_state = ENTER_INACTIVE_STATE;


	for(;;) {
		uint32_t current_time = time(NULL);
		switch (system_state) {
			case ENTER_INACTIVE_STATE:
				ESP_LOGI(TAG, "Entering Inactive State\n");
				system_state = INACTIVE_STATE;
				break;
			case INACTIVE_STATE:

//				esp_wifi_stop();
//				gpio_hold_en(0);
//				esp_sleep_enable_gpio_wakeup();
//			    gpio_wakeup_enable(SWITCH_IN_IO, GPIO_INTR_HIGH_LEVEL);
//				esp_light_sleep_start();
//				gpio_hold_dis(0);
//				printf("awake\n");
//				gpio_wakeup_disable(SWITCH_IN_IO);
//				esp_wifi_restore();

				if (flag_enter_active_state) {
					flag_enter_active_state = false;
					system_state = ENTER_ACTIVE_STATE;
				}
				break;
			case ENTER_ACTIVE_STATE:
				ESP_LOGI(TAG, "Entering Active State\n");
				SetSwitchColour(SWITCH_COLOUR_GREEN);printf("GREEN %u\n", __LINE__);
				upload_time_last = current_time + UPLOAD_PERIOD_ACTIVE_S;
				system_state = ACTIVE_STATE;
				break;
			case ACTIVE_STATE:
				if (flag_enter_inactive_state) {
					flag_enter_inactive_state = false;
					system_state = ENTER_INACTIVE_STATE;
				} else if (wifi_state == WIFI_DISCONNECTED) {
					system_state = ENTER_DISCONNECTED_STATE;
				} else if (current_time - upload_time_last >= UPLOAD_PERIOD_ACTIVE_S) {
					upload_time_last = current_time;

					ESP_LOGI(TAG, "Reading sensors");

					ADCRead(&adc_params, &adc_reading);
//					adc_reading.raw_reading = adc_reading.raw_reading < BATTERY_MIN_READING ? BATTERY_MIN_READING : adc_reading.raw_reading;
//					adc_reading.raw_reading = adc_reading.raw_reading > BATTERY_MAX_READING ? BATTERY_MAX_READING : adc_reading.raw_reading;
//					battery_level = round((100 * (adc_reading.raw_reading - BATTERY_MIN_READING)) / (BATTERY_MAX_READING - BATTERY_MIN_READING));
					battery_level = adc_reading.raw_reading;

					gpio_set_level(LED_PWR_IO, 1);

					for (uint8_t i = 0; i < SENSOR_COUNT; i++) {
						od_successes[i] = false;
						od_successes[i] = ReadBH1790GLC(i + 1, &od_readings[i]);
					}
					gpio_set_level(LED_PWR_IO, 0);

					vTaskDelay(1 / portTICK_RATE_MS);
					temperature_success = ReadSHT4X(&temperature, &relative_humidity);

					// Upload to Thingsboard
					ESP_LOGI(TAG, "Uploading to Thingsboard");
					sprintf(data_str, "{");
					sprintf(data_str + strlen(data_str), "\"status\":\"active\"");
					sprintf(data_str + strlen(data_str), ",\"battery\":%u", battery_level);
					for (uint8_t i = 0; i < SENSOR_COUNT; i++) {
						if (od_successes[i]) {
							sprintf(data_str + strlen(data_str), ",\"OD%u\":%f", i + 1, od_readings[i]);
						} else {
							sprintf(data_str + strlen(data_str), ",\"OD%u\":\"\"", i + 1);
						}
					}
					if (temperature_success) {
						sprintf(data_str + strlen(data_str), ",\"temperature\":%f", temperature);
						sprintf(data_str + strlen(data_str), ",\"humidity\":%f", relative_humidity);
					}
					sprintf(data_str + strlen(data_str), "}");

					publish_mqtt_data(data_str);
				}
				break;
			case ENTER_DISCONNECTED_STATE:
				ESP_LOGI(TAG, "Entering Disconnected State\n");
				SetSwitchColour(SWITCH_COLOUR_RED);printf("RED %u\n", __LINE__);
				system_state = DISCONNECTED_STATE;
				break;
			case DISCONNECTED_STATE: ;
				if (wifi_state == WIFI_CONNECTED) {
					system_state = ENTER_ACTIVE_STATE;
				}
				break;
			default:
				break;
		};
		vTaskDelay(1);
	}
}
