# FloDX Firmware

This ESP-IDF project runs on FloDX hardware.

It can read optical and environmental sensors and transmit the data to ThingsBoard.

## WiFi configuration & ThingsBoard provisioning guide

### Provisioning a new device

When the device is in Access Point mode, the LED is blue. This will be the case when the device is programmed for the first time.

Take a note of the unique MAC address of the device. You can find this by looking at available WiFi networks for an SSID that begins with “FLODX_”. The MAC address follows this, e.g. for an SSID of FLODX_E0:E2:E6:70:84:58, the MAC address is E0:E2:E6:70:84:58.

The device is provisioned using the “ESP Provisioning” Android application.

Using the app you can either scan a QR code if you have generated it using the Customer Admin dashboard on ThingsBoard or follow these steps:
1.	Select “Provision New Device”
2.	Select “I don’t have a QR code”
3.	Select SoftAP as Device Type
4.	Click “Connect”
5.	Connect to the network with SSID beginning with “FLODX_” …
6.	… using the password “PROV_PASS”
7.	Return to the app and enter the proof of possession PIN “abcd1234”
8.	Enter the Network Name and Password of the network you want the device to connect to
9.	If the three ticks appear successfully, the WiFi provisioning is complete.

Once the WiFi is provisioned and successfully connected, there will be a 10-minute window in which the Customer admin can “claim” the device on ThingsBoard. On the Customer admin dashboard, enter the device’s MAC address into the Claim Device field and click “Claim Device”. If successful, the device will appear in the Device admin table with the device’s MAC address as its “Entity name”. To assign this to a user, select the “edit device” button (the pencil icon) and enter the email address of the user (and, optionally, a display name for the device that’s more human-readable than the MAC address).

Now the Customer user can see the device in the list of devices on their dashboard when they sign into ThingsBoard Cloud.

### Provisioning a device again

If a device was previously provisioned, several steps must be followed. First, the device should be deleted from ThingsBoard. The Customer admin that claimed the device can go to Device Groups and select the Open button on the Device group named “All”. In the table of devices that opens, they can delete the device they wish to reprogram using the Delete button. If this fails with the warning “Can’t delete device that has entity views!”, this is because there are experiments associated with the device which must be deleted first to allow deletion of the device.

Note that if device provisioning fails later even though it was previously deleted, it might be the case that the device is still registered outside of the Customer admin’s scope and must be deleted by the Tenant Admin from Device Groups>All. Certainly, this will always be necessary if the device was not claimed within the ten-minute window.

The device can be reset to factory settings by holding down the button for 5 seconds until the LED turns blue. Then you are ready to follow the above instructions for “Provisioning a new device”.

### ThingsBoard Cloud information

The website is thingsboard.cloud. Sample accounts exist which can be used for testing.

Customer admin:
```
username: nimbusadmin1@nimbus.com
password: uAFM#Y2X#E*4
```

Customer user:
```
username: nimbususer1@nimbus.com
password: uAFM#Y2X#E*4
```

Tenant administrator:
```
username: vvb.yallapragada@mtu.ie
password: Userflodx1
```

### Generating a QR code (optional)

To generate a QR code to be optionally used to configure a device from the ESP Provisioning app, you need to use a QR code generator. A QR code generator is provided on the Customer Admin ThingsBoard dashboard which can generate the appropriate QR code using only the MAC address of the device.

Here is an example:
```
MAC address:
E0:E2:E6:70:84:58

QR code text: 
{"ver":"v1","name":"FLODX_E0:E2:E6:70:84:58","pop":"abcd1234","transport":"softap","password":"PROV_PASS"}
```
